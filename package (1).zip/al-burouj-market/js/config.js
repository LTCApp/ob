// Supabase Configuration
const SUPABASE_URL = 'https://zcjqkexfaecozubfptod.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_wMIbC1w3GjZnjv1vz8dEwg_2HsG0I17';

// App Configuration
const APP_CONFIG = {
    siteName: 'OB',
    siteFullName: 'OB - لأهل العبور',
    location: 'العبور',
    whatsappNumber: '20',
    adDurationDays: 30,
    expiringAlertDays: 2,
    adsPerPage: 12,
    featuredAdPrice: 25, // سعر تمييز الإعلان
    adminEmails: ['admin@ob.com'], // حسابات الأدمن
    seo: {
        title: 'OB - منصة بيع وشراء محلية في العبور',
        description: 'منصة محلية لبيع وشراء السلع والخدمات بين سكان مدينة العبور، تتيح للمستخدمين نشر الإعلانات بسهولة والتواصل المباشر عبر واتساب، مع تصفح منظم حسب الأقسام والمناطق لسرعة الوصول لأفضل العروض.',
        keywords: 'بيع, شراء, العبور, موبايلات, سيارات, عقارات, خدمات, إعلانات',
        author: 'OB Team',
        ogImage: '/images/og-image.jpg'
    }
};

// Categories
const CATEGORIES = [
    { id: 'mobiles', name: 'موبايلات', icon: 'phone', count: 0 },
    { id: 'cars', name: 'سيارات', icon: 'car', count: 0 },
    { id: 'real-estate', name: 'عقارات', icon: 'home', count: 0 },
    { id: 'electronics', name: 'أجهزة', icon: 'laptop', count: 0 },
    { id: 'services', name: 'خدمات', icon: 'tool', count: 0 }
];

// Neighborhoods
const NEIGHBORHOODS = [
    'الحي الأول',
    'الحي الثاني',
    'الحي الثالث',
    'الحي الرابع',
    'الحي الخامس',
    'الحي السادس',
    'الحي السابع',
    'الحي الثامن',
    'الحي التاسع',
    'الحي العاشر',
    'المنطقة الصناعية',
    'المراكز التجارية'
];

// Ad Status
const AD_STATUS = {
    PENDING: 'pending',
    ACTIVE: 'active',
    FEATURED: 'featured',
    EXPIRED: 'expired',
    REJECTED: 'rejected'
};
