-- =============================================
-- OB - لأهل العبور
-- قاعدة البيانات الكاملة لـ Supabase
-- =============================================

-- انسخ هذا الكود والصقه في SQL Editor في Supabase
-- بعد إنشاء مشروع Supabase جديد

-- =============================================
-- 1. تفعيل الاضافات المطلوبة
-- =============================================

-- pg_stat_statements للتتبع (اختياري)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================
-- 2. جدول المستخدمين (users)
-- =============================================

CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE,
    phone TEXT UNIQUE,
    name TEXT,
    avatar_url TEXT,
    provider TEXT DEFAULT 'email',
    provider_id TEXT,
    whatsapp TEXT,
    is_active BOOLEAN DEFAULT true,
    is_admin BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- فهارس
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users(email);
CREATE INDEX IF NOT EXISTS idx_users_phone ON public.users(phone);
CREATE INDEX IF NOT EXISTS idx_users_provider ON public.users(provider);

-- =============================================
-- 3. جدول الأقسام (categories)
-- =============================================

CREATE TABLE IF NOT EXISTS public.categories (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    slug TEXT UNIQUE NOT NULL,
    name_ar TEXT NOT NULL,
    name_en TEXT,
    icon TEXT,
    color TEXT DEFAULT '#2563EB',
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- إدخال الأقسام الافتراضية
INSERT INTO public.categories (slug, name_ar, name_en, icon, color, sort_order) VALUES
    ('mobiles', 'موبايلات', 'Mobiles', 'smartphone', '#2563EB', 1),
    ('cars', 'سيارات', 'Cars', 'car', '#10B981', 2),
    ('real-estate', 'عقارات', 'Real Estate', 'building', '#F59E0B', 3),
    ('electronics', 'أجهزة', 'Electronics', 'laptop', '#8B5CF6', 4),
    ('services', 'خدمات', 'Services', 'tool', '#EC4899', 5)
ON CONFLICT (slug) DO NOTHING;

-- =============================================
-- 4. جدول الأحياء (neighborhoods)
-- =============================================

CREATE TABLE IF NOT EXISTS public.neighborhoods (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name TEXT UNIQUE NOT NULL,
    sort_order INTEGER DEFAULT 0,
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- إدخال الأحياء الافتراضية
INSERT INTO public.neighborhoods (name, sort_order) VALUES
    ('الحي الأول', 1),
    ('الحي الثاني', 2),
    ('الحي الثالث', 3),
    ('الحي الرابع', 4),
    ('الحي الخامس', 5),
    ('الحي السادس', 6),
    ('الحي السابع', 7),
    ('الحي الثامن', 8),
    ('الحي التاسع', 9),
    ('الحي العاشر', 10),
    ('المنطقة الصناعية', 11),
    ('المراكز التجارية', 12)
ON CONFLICT (name) DO NOTHING;

-- =============================================
-- 5. جدول الإعلانات (ads) - الجدول الرئيسي
-- =============================================

CREATE TABLE IF NOT EXISTS public.ads (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    description TEXT,
    price DECIMAL(12, 2) NOT NULL DEFAULT 0,
    category TEXT,
    neighborhood TEXT,
    images TEXT[] DEFAULT '{}',
    whatsapp TEXT NOT NULL,
    status TEXT DEFAULT 'pending' CHECK (status IN ('pending', 'active', 'featured', 'expired', 'rejected', 'sold')),
    is_featured BOOLEAN DEFAULT false,
    featured_until TIMESTAMPTZ,
    views INTEGER DEFAULT 0,
    contact_count INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    expires_at DATE,
    published_at TIMESTAMPTZ,
    renewed_at TIMESTAMPTZ,
    rejected_reason TEXT,
    metadata JSONB DEFAULT '{}'
);

-- فهارس الإعلانات
CREATE INDEX IF NOT EXISTS idx_ads_user_id ON public.ads(user_id);
CREATE INDEX IF NOT EXISTS idx_ads_status ON public.ads(status);
CREATE INDEX IF NOT EXISTS idx_ads_category ON public.ads(category);
CREATE INDEX IF NOT EXISTS idx_ads_neighborhood ON public.ads(neighborhood);
CREATE INDEX IF NOT EXISTS idx_ads_created_at ON public.ads(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ads_expires_at ON public.ads(expires_at);
CREATE INDEX IF NOT EXISTS idx_ads_price ON public.ads(price);
CREATE INDEX IF NOT EXISTS idx_ads_featured ON public.ads(is_featured) WHERE is_featured = true;

-- =============================================
-- 6. جدول المفضلة (favorites)
-- =============================================

CREATE TABLE IF NOT EXISTS public.favorites (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    ad_id UUID REFERENCES public.ads(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, ad_id)
);

CREATE INDEX IF NOT EXISTS idx_favorites_user_id ON public.favorites(user_id);
CREATE INDEX IF NOT EXISTS idx_favorites_ad_id ON public.favorites(ad_id);

-- =============================================
-- 7. جدول الرسائل (messages)
-- =============================================

CREATE TABLE IF NOT EXISTS public.messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    ad_id UUID REFERENCES public.ads(id) ON DELETE CASCADE,
    sender_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    sender_name TEXT,
    sender_email TEXT,
    sender_phone TEXT,
    content TEXT NOT NULL,
    is_read BOOLEAN DEFAULT false,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_messages_ad_id ON public.messages(ad_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender_id ON public.messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_messages_created_at ON public.messages(created_at DESC);

-- =============================================
-- 8. جدول إعدادات الموقع (site_settings)
-- =============================================

CREATE TABLE IF NOT EXISTS public.site_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key TEXT UNIQUE NOT NULL,
    value JSONB DEFAULT '{}',
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    updated_by UUID REFERENCES public.users(id)
);

-- إعدادات افتراضية
INSERT INTO public.site_settings (key, value) VALUES
    ('site_info', '{"name": "OB", "full_name": "OB - لأهل العبور", "description": "منصة محلية لبيع وشراء السلع والخدمات بين سكان مدينة العبور"}'),
    ('seo', '{"title": "OB - منصة بيع وشراء محلية في العبور", "description": "منصة محلية لبيع وشراء السلع والخدمات بين سكان مدينة العبور", "keywords": "بيع, شراء, العبور, موبايلات, سيارات, عقارات, خدمات, إعلانات", "author": "OB Team"}'),
    ('contact', '{"email": "contact@ob.com", "whatsapp": "201000000000"}'),
    ('ads', '{"default_duration_days": 30, "featured_price": 25, "max_images": 5, "max_title_length": 100, "expiring_alert_days": 2}')
ON CONFLICT (key) DO NOTHING;

-- =============================================
-- 9. جدول سجل النشاطات (activity_logs)
-- =============================================

CREATE TABLE IF NOT EXISTS public.activity_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    action TEXT NOT NULL,
    entity_type TEXT,
    entity_id UUID,
    old_value JSONB,
    new_value JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_activity_logs_user_id ON public.activity_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_action ON public.activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_activity_logs_entity ON public.activity_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_activity_logs_created_at ON public.activity_logs(created_at DESC);

-- =============================================
-- 10. جدول الإشعارات (notifications)
-- =============================================

CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    title TEXT NOT NULL,
    body TEXT,
    type TEXT DEFAULT 'info',
    is_read BOOLEAN DEFAULT false,
    data JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON public.notifications(is_read) WHERE is_read = false;
CREATE INDEX IF NOT EXISTS idx_notifications_created_at ON public.notifications(created_at DESC);

-- =============================================
-- الدوال (Functions) والتوقيتات (Triggers)
-- =============================================

-- دالة لتحديث وقت التحديث
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- تطبيق التوقيت على الجداول
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON public.users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_ads_updated_at ON PUBLIC.ads;
CREATE TRIGGER update_ads_updated_at
    BEFORE UPDATE ON public.ads
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

DROP TRIGGER IF EXISTS update_site_settings_updated_at ON public.site_settings;
CREATE TRIGGER update_site_settings_updated_at
    BEFORE UPDATE ON public.site_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- دالة لتعيين تاريخ انتهاء الإعلان
CREATE OR REPLACE FUNCTION set_ad_expiration()
RETURNS TRIGGER AS $$
BEGIN
    -- عند إضافة إعلان جديد
    IF NEW.status IN ('active', 'featured') AND NEW.expires_at IS NULL THEN
        NEW.expires_at := NOW()::date + INTERVAL '30 days';
        NEW.published_at := NOW();
    END IF;

    -- تحويل للإعلان المميز
    IF NEW.is_featured = true AND NEW.status = 'active' THEN
        NEW.status := 'featured';
        NEW.featured_until := NOW() + INTERVAL '30 days';
    END IF;

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_ad_expiration_trigger ON public.ads;
CREATE TRIGGER set_ad_expiration_trigger
    BEFORE INSERT OR UPDATE ON public.ads
    FOR EACH ROW EXECUTE FUNCTION set_ad_expiration();

-- دالة لإنهاء الإعلانات المنتهية تلقائياً
CREATE OR REPLACE FUNCTION expire_old_ads()
RETURNS void AS $$
BEGIN
    UPDATE public.ads
    SET status = 'expired'
    WHERE status IN ('active', 'featured')
      AND expires_at < NOW()::date;
END;
$$ LANGUAGE plpgsql;

-- =============================================
-- Row Level Security (RLS)
-- =============================================

-- تفعيل RLS على جميع الجداول
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.ads ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.favorites ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.activity_logs ENABLE ROW LEVEL SECURITY;

-- ===== سياسات المستخدمين =====

-- يمكن للجميع رؤية المستخدمين
CREATE POLICY "Public users can view all users"
    ON public.users FOR SELECT
    USING (true);

-- المستخدم يمكنه تحديث بياناته
CREATE POLICY "Users can update own profile"
    ON public.users FOR UPDATE
    USING (auth.uid() = id);

-- المستخدم يمكنه إضافة بياناته
CREATE POLICY "Users can insert own profile"
    ON public.users FOR INSERT
    WITH CHECK (auth.uid() = id);

-- ===== سياسات الإعلانات =====

-- يمكن للجميع رؤية الإعلانات النشطة
CREATE POLICY "Anyone can view active ads"
    ON public.ads FOR SELECT
    USING (
        status IN ('active', 'featured', 'sold')
        OR user_id = auth.uid()
        OR EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND is_admin = true)
    );

-- المستخدمون المسجلون يمكنهم إضافة إعلانات
CREATE POLICY "Authenticated users can create ads"
    ON public.ads FOR INSERT
    WITH CHECK (auth.uid() IS NOT NULL);

-- المستخدم يمكنه تحديث إعلاناته
CREATE POLICY "Users can update own ads"
    ON public.ads FOR UPDATE
    USING (user_id = auth.uid());

-- المستخدم يمكنه حذف إعلاناته
CREATE POLICY "Users can delete own ads"
    ON public.ads FOR DELETE
    USING (user_id = auth.uid());

-- ===== سياسات المفضلة =====

-- المستخدم يمكنه رؤية مفضلاته
CREATE POLICY "Users can view own favorites"
    ON public.favorites FOR SELECT
    USING (user_id = auth.uid());

-- المستخدم يمكنه إضافة للمفضلة
CREATE POLICY "Users can add favorites"
    ON public.favorites FOR INSERT
    WITH CHECK (user_id = auth.uid());

-- المستخدم يمكنه حذف من مفضلاته
CREATE POLICY "Users can remove own favorites"
    ON public.favorites FOR DELETE
    USING (user_id = auth.uid());

-- ===== سياسات الرسائل =====

-- المستخدم يمكنه رؤية رسائل إعلاناته
CREATE POLICY "Users can view messages on own ads"
    ON public.messages FOR SELECT
    USING (
        EXISTS (SELECT 1 FROM public.ads WHERE ads.id = ad_id AND ads.user_id = auth.uid())
        OR sender_id = auth.uid()
    );

-- أي شخص يمكنه إرسال رسالة
CREATE POLICY "Anyone can send messages"
    ON public.messages FOR INSERT
    WITH CHECK (true);

-- المستخدم يمكنه تحديث رسائله
CREATE POLICY "Users can update own messages"
    ON public.messages FOR UPDATE
    USING (sender_id = auth.uid());

-- ===== سياسات الإشعارات =====

-- المستخدم يمكنه رؤية إشعاراته
CREATE POLICY "Users can view own notifications"
    ON public.notifications FOR SELECT
    USING (user_id = auth.uid());

-- المستخدم يمكنه تحديث إشعاراته
CREATE POLICY "Users can update own notifications"
    ON public.notifications FOR UPDATE
    USING (user_id = auth.uid());

-- ===== سياسات سجل النشاطات - للأدمن فقط =====

CREATE POLICY "Admins can view all activity logs"
    ON public.activity_logs FOR SELECT
    USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND is_admin = true)
    );

-- ===== الأقسام والأحياء - للقراءة فقط =====

CREATE POLICY "Anyone can view active categories"
    ON public.categories FOR SELECT
    USING (is_active = true);

CREATE POLICY "Anyone can view active neighborhoods"
    ON public.neighborhoods FOR SELECT
    USING (is_active = true);

-- ===== إعدادات الموقع =====

CREATE POLICY "Anyone can view site settings"
    ON public.site_settings FOR SELECT
    USING (true);

CREATE POLICY "Admins can update site settings"
    ON public.site_settings FOR UPDATE
    USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND is_admin = true)
    );

-- =============================================
-- Storage Bucket لصور الإعلانات
-- =============================================

-- أنشئ Bucket في Supabase Dashboard:
-- Name: ad-images
-- Public: true

-- يمكن تنفيذ هذا يدوياً في Supabase Dashboard
-- أو استخدم الكود التالي في SQL (إذا كان لديك الصلاحيات):

-- INSERT INTO storage.buckets (id, name, public)
-- VALUES ('ad-images', 'ad-images', true)
-- ON CONFLICT (id) DO NOTHING;

-- ===== سياسات Storage =====

-- CREATE POLICY "Anyone can upload ad images"
--     ON storage.objects FOR INSERT
--     WITH CHECK (bucket_id = 'ad-images');

-- CREATE POLICY "Anyone can view ad images"
--     ON storage.objects FOR SELECT
--     USING (bucket_id = 'ad-images');

-- CREATE POLICY "Users can update ad images"
--     ON storage.objects FOR UPDATE
--     USING (bucket_id = 'ad-images');

-- CREATE POLICY "Users can delete ad images"
--     ON storage.objects FOR DELETE
--     USING (bucket_id = 'ad-images');

-- =============================================
-- طريقة تفعيل Google OAuth في Supabase
-- =============================================

-- 1. اذهب إلى Supabase Dashboard
-- 2. اختر مشروعك
-- 3. اذهب إلى Authentication > Providers
-- 4. فعّل Google
-- 5. أدخل:
--    - Client ID: من Google Cloud Console
--    - Client Secret: من Google Cloud Console
--    - Authorized Redirect URI: من Supabase

-- =============================================
-- طريقة تفعيل Facebook OAuth في Supabase
-- =============================================

-- 1. اذهب إلى Supabase Dashboard
-- 2. اختر مشروعك
-- 3. اذهب إلى Authentication > Providers
-- 4. فعّل Facebook
-- 5. أدخل:
--    - Client ID: من Meta Developer Console
--    - Client Secret: من Meta Developer Console
--    - Authorized Redirect URI: من Supabase

-- =============================================
-- مستخدم الأدمن الافتراضي
-- =============================================

-- أنشئ مستخدم الأدمن (غيّر الإيميل لأدمن فعلي)
-- INSERT INTO public.users (email, name, is_admin, provider)
-- VALUES ('admin@ob.com', 'المشرف العام', true, 'email');

-- =============================================
-- Cron Job للإنهاء التلقائي (Supabase Pro)
-- =============================================

-- فعّل pg_cron أولاً (يتطلب Supabase Pro)

-- CREATE EXTENSION IF NOT EXISTS pg_cron;

-- جدولة إنهاء الإعلانات كل ساعة
-- SELECT cron.schedule('auto-expire-ads', '0 * * * *', 'SELECT expire_old_ads()');

-- =============================================
-- Views للاستعلام السريع
-- =============================================

-- عرض الإعلانات النشطة مع بيانات المستخدم
CREATE OR REPLACE VIEW public.active_ads_with_users AS
SELECT
    a.id,
    a.title,
    a.description,
    a.price,
    a.category,
    a.neighborhood,
    a.images,
    a.whatsapp,
    a.status,
    a.is_featured,
    a.views,
    a.created_at,
    a.expires_at,
    u.name as user_name,
    u.avatar_url as user_avatar,
    u.whatsapp as user_whatsapp
FROM public.ads a
LEFT JOIN public.users u ON a.user_id = u.id
WHERE a.status IN ('active', 'featured')
  AND (a.expires_at IS NULL OR a.expires_at >= NOW()::date);

-- عرض الإعلانات المميزة
CREATE OR REPLACE VIEW public.featured_ads AS
SELECT * FROM public.ads
WHERE status = 'featured'
  AND (featured_until IS NULL OR featured_until > NOW())
ORDER BY created_at DESC;

-- إحصائيات الإعلانات حسب القسم
CREATE OR REPLACE VIEW public.ads_stats_by_category AS
SELECT
    category,
    COUNT(*) as total_ads,
    COUNT(*) FILTER (WHERE status = 'active') as active_ads,
    COUNT(*) FILTER (WHERE status = 'featured') as featured_ads,
    AVG(price) as avg_price,
    MAX(price) as max_price,
    MIN(price) as min_price
FROM public.ads
WHERE status IN ('active', 'featured')
  AND (expires_at IS NULL OR expires_at >= NOW()::date)
GROUP BY category;

-- =============================================
-- بيانات تجريبية للاختبار
-- =============================================

-- ملاحظة: قم بإلغاء تعليق الكود التالي للاختبار

-- مستخدم تجريبي
-- INSERT INTO public.users (id, email, name, provider)
-- VALUES (
--     '11111111-1111-1111-1111-111111111111',
--     'test@example.com',
--     'مستخدم تجريبي',
--     'email'
-- );

-- إعلان تجريبي
-- INSERT INTO public.ads (user_id, title, description, price, category, neighborhood, whatsapp, status, expires_at)
-- VALUES (
--     '11111111-1111-1111-1111-111111111111',
--     'آيفون 14 برو ماكس - بحالة ممتازة',
--     'آيفون 14 برو ماكس لون ذهبي، سعة 256 جيجا، بحالة ممتازة بدون أي خدوش أو مشاكل. يشمل العلبة الأصلية والشاحن. البطارية 100%.',
--     45000,
--     'mobiles',
--     'الحي الأول',
--     '01123456789',
--     'active',
--     NOW()::date + INTERVAL '30 days'
-- );

-- =============================================
-- نهاية ملف قاعدة البيانات
-- =============================================
